import React from 'react'

export default function index(props) {
    console.log(props)
    return (
        <div>
            <p>x:<span>0</span></p>
            <p>y:<span>0</span></p>
        </div>
    )
}
